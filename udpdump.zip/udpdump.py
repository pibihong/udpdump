

import sys

def welcome():
    print "tcpdump plugin by bihongpi~~~"

def proc_udp(buf):
    sys.stdout.write( '\n%d' % len(buf) )





